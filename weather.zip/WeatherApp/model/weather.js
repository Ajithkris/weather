const mongoose = require('mongoose');

const weatherSchema = mongoose.Schema({
    place_name: {
        type: String,
        required: true
    },
    temperature: {
        type: String
    }
}, { timestamps: true });

const Weather = mongoose.model('weather', weatherSchema);

module.exports = Weather;