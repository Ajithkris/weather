const express = require('express');
require('../db/mongoose');
const app = express();
app.use(express.json());

const port = process.env.PORT || 3001

const weatherRouter = require('../router/weather');

app.use('/api', weatherRouter);

app.listen(port, () => {
    console.log(`starting server at ${port}`);
})