const request = require('request');


const foreCast = (placeName) => {
    return new Promise((resolve, reject) => {
        const url = `https://api.weatherbit.io/v2.0/current?city=${placeName}&key=373ea9a7994d4ea99eb93af6cf9fa46d&include=minutely`;
        request({
            url,
            json: true
        }, (error, res, body) => {
            if (error) {
                return reject(error);
            } else {
                return resolve(body.data[0].temp)
            }
        })
    })

}

module.exports = foreCast;