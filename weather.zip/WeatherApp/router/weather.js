const express = require('express');
const router = express.Router();
const Weather = require('../model/weather');
const foreCast = require('../util/forecast');

router.post('/weather', async (req, res) => {
    try {
        const placeName = req.query.place_name;
        const temp = await foreCast(placeName)
        const place = await Weather({ place_name: placeName, temperature: temp }).save()
        return res.status(200).send(place)
    } catch (error) {
        return res.status(500).send(error)
    }
})



module.exports = router;